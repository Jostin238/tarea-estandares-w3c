// Muestra un mensaje cuando se presiona el botón.
document.addEventListener("DOMContentLoaded", function () {
    var boton = document.getElementById("boton-mensaje");

    if (boton) {
        boton.addEventListener("click", function () {
            document.getElementById("mensaje").textContent =
                "Gracias por visitar mi página.";
        });
    }
});
